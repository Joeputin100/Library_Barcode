import barcode
from barcode.writer import ImageWriter
import qrcode
from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.platypus.flowables import KeepInFrame
import io
import shutil

# Avery 5160 label dimensions (approximate, for layout)
LABEL_WIDTH = 2.625 * inch
LABEL_HEIGHT = 1.0 * inch
LABELS_PER_SHEET_WIDTH = 3
LABELS_PER_SHEET_HEIGHT = 10
PAGE_WIDTH, PAGE_HEIGHT = letter # 8.5 x 11 inches

# Margins for Avery 5160 (standard, adjust if needed)
LEFT_MARGIN = 0.1875 * inch
TOP_MARGIN = 0.5 * inch
HORIZONTAL_SPACING = 0.125 * inch # Space between labels horizontally
VERTICAL_SPACING = 0.0 * inch # Space between labels vertically (they touch)

def pad_inventory_number(inventory_num):
    """Pads the inventory number with leading zeros to 6 digits."""
    return str(inventory_num).zfill(6)

def generate_barcode(inventory_num):
    """Generates a Code 128 barcode image for the given inventory number."""
    padded_num = pad_inventory_number(inventory_num)
    EAN = barcode.get('code128', padded_num, writer=ImageWriter())
    # Save to a BytesIO object to avoid writing to disk
    buffer = io.BytesIO()
    EAN.write(buffer)
    buffer.seek(0)
    return ImageReader(buffer)

def generate_qrcode(inventory_num):
    """Generates a QR code image for the given inventory number."""
    padded_num = pad_inventory_number(inventory_num)
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(padded_num)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    # Save to a BytesIO object
    buffer = io.BytesIO()
    img.save(buffer, format="PNG")
    buffer.seek(0)
    return ImageReader(buffer)

def _fit_text_to_box(c, text_lines, font_name, max_width, max_height, initial_font_size=10, min_font_size=5, alignment=TA_LEFT):
    """
    Finds the largest font size that allows all text_lines to fit within max_width and max_height.
    Returns the optimal font size and the calculated height of the text block.
    """
    styles = getSampleStyleSheet()
    style = styles['Normal']
    optimal_font_size = min_font_size
        style.fontSize = min_font_size
        text_block_height = 0
        for line in text_lines:
            p = Paragraph(line, style)
            width, height = p.wrapOn(c, max_width, max_height)
            text_block_height += height + (0.05 * inch)

    return optimal_font_size, text_block_height

def create_label(c, x, y, book_data, label_type):
    """
    Renders content for a single label on the PDF canvas.
    c: reportlab canvas object
    x, y: bottom-left coordinates of the label
    book_data: dictionary containing book information
    label_type: 1, 2, 3, or 4
    """
    title = book_data.get('title', '')
    authors = book_data.get('authors', '')
    publication_year = book_data.get('publication_year', '')
    series_name = book_data.get('series_name', '')
    series_number = book_data.get('series_number', '')
    dewey_number = book_data.get('dewey_number', '')
    inventory_number = pad_inventory_number(book_data.get('inventory_number', ''))

    if label_type == 1:
        # Label 1: title, authors, publication year, series, Dewey, inventory number
        text_lines = [
            title,
            authors,
            str(publication_year),
        ]
        if series_name:
            text_lines.append(f"{series_name} #{series_number}" if series_number else series_name)
        text_lines.append(dewey_number)
        text_lines.append(inventory_number)

        # Dynamic font sizing for Label 1
        max_text_width = LABEL_WIDTH - 10 # 5 units margin on each side
        max_text_height = LABEL_HEIGHT - 10 # 5 units margin on top/bottom
        
        optimal_font_size, text_block_height = _fit_text_to_box(c, text_lines, 'Courier', max_text_width, max_text_height, initial_font_size=18) # Increased initial font size
        
        styles = getSampleStyleSheet()
        style = styles['Normal']
        style.fontName = 'Courier'
        style.fontSize = optimal_font_size
        style.leading = optimal_font_size * 1.2 # Line spacing

        # Calculate vertical start position to center text block within the label
        current_y = y + (LABEL_HEIGHT + text_block_height) / 2 - (optimal_font_size * 0.2) # Adjusted for baseline and centering

        for line in text_lines:
            p = Paragraph(line, style)
            width, height = p.wrapOn(c, max_text_width, max_text_height) # Wrap text within the box
            current_y -= height # Move down for current line
            p.drawOn(c, x + 5, current_y) # Draw from top down
            current_y -= (0.05 * inch) # Add line spacing

    elif label_type == 2:
        # Label 2: title, author, series, inventory number, QR code (half label)
        qr_code_size = LABEL_HEIGHT * 0.9 # Make QR code 20% larger (0.8 * 1.2 = 0.96, rounded to 0.9)
        qr_code_x = x + LABEL_WIDTH - qr_code_size - 2 # 2 units from right edge
        qr_code_y = y + (LABEL_HEIGHT - qr_code_size) / 2

        qr_image = generate_qrcode(inventory_number)
        c.drawImage(qr_image, qr_code_x, qr_code_y, width=qr_code_size, height=qr_code_size)

        text_lines = [
            title,
            authors.split(',')[0] if authors else '', # Just first author
        ]
        if series_name:
            text_lines.append(f"{series_name} #{series_number}" if series_number else series_name)
        text_lines.append(inventory_number)

        # Calculate text area width (left of QR code) and height
        max_text_width = LABEL_WIDTH - qr_code_size - 10 # 10 units for margins
        max_text_height = LABEL_HEIGHT - 10 # 5 units margin on top/bottom

        optimal_font_size, text_block_height = _fit_text_to_box(c, text_lines, 'Courier', max_text_width, max_text_height, initial_font_size=12) # Increased initial font size
        
        styles = getSampleStyleSheet()
        style = styles['Normal']
        style.fontName = 'Courier'
        style.fontSize = optimal_font_size
        style.leading = optimal_font_size * 1.2 # Line spacing

        # Calculate vertical start position to center text block
        current_y = y + (LABEL_HEIGHT - text_block_height) / 2 + text_block_height # Adjust for baseline

        for line in text_lines:
            p = Paragraph(line, style)
            width, height = p.wrapOn(c, max_text_width, max_text_height) # Wrap text within the box
            current_y -= height # Move down for current line
            p.drawOn(c, x + 5, current_y) # Draw from top down
            current_y -= (0.05 * inch) # Add line spacing

    elif label_type == 3:
        # Label 3 (Spine Label): Dewey, author (3 letters), year, inventory number (centered)
        c.setFont('Courier-Bold', 10)
        lines = [
            dewey_number,
            authors[:3].upper() if authors else '',
            str(publication_year),
            inventory_number
        ]
        
        # Calculate vertical position for centered text
        line_height = 12 # Approximate line height for font size 10
        total_text_height = len(lines) * line_height
        # Corrected vertical centering: y + (LABEL_HEIGHT - total_text_height) / 2
        start_y = y + (LABEL_HEIGHT - total_text_height) / 2 + total_text_height - (line_height * 0.8) # Adjust for baseline

        for i, line in enumerate(lines):
            text_width = c.stringWidth(line, 'Courier-Bold', 10)
            c.drawString(x + (LABEL_WIDTH - text_width) / 2, start_y - (i * line_height), line)

    elif label_type == 4:
        # Label 4: title, author, series, inventory number (text + barcode - 75% label)
        barcode_height = LABEL_HEIGHT * 0.6 # Make barcode slightly smaller to allow space for text above
        barcode_width = LABEL_WIDTH * 0.8 # Adjust as needed for aspect ratio
        barcode_x = x + LABEL_WIDTH - barcode_width - 5 # Move to right side, 5 units from edge
        barcode_y = y + (LABEL_HEIGHT - barcode_height) / 2 - 0.1 * inch # Move lower on the label

        barcode_image = generate_barcode(inventory_number)
        c.drawImage(barcode_image, barcode_x, barcode_y, width=barcode_width, height=barcode_height)

        # Text above barcode (Title, Author)
        text_above_barcode_lines = [
            f"{title} by {authors.split(',')[0] if authors else ''}", # Combined title and author
        ]
        max_text_above_width = LABEL_WIDTH - 10 # 10 units for margins
        max_text_above_height = LABEL_HEIGHT - barcode_height - (y + (LABEL_HEIGHT - barcode_height) / 2 - barcode_y) - 5 # Space above barcode

        optimal_font_size_above, text_block_height_above = _fit_text_to_box(c, text_above_barcode_lines, 'Courier', max_text_above_width, max_text_above_height, initial_font_size=10, alignment=TA_CENTER)
        
        styles = getSampleStyleSheet()
        style_above = styles['Normal']
        style_above.fontName = 'Courier'
        style_above.fontSize = optimal_font_size_above
        style_above.leading = optimal_font_size_above * 1.2 # Line spacing
        style_above.alignment = TA_CENTER # Center text horizontally

        current_y_above = y + LABEL_HEIGHT - 5 # Start near top of label
        for line in text_above_barcode_lines:
            p = Paragraph(line, style_above)
            width, height = p.wrapOn(c, max_text_above_width, max_text_above_height) # Wrap text within the box
            current_y_above -= height # Move down for current line
            p.drawOn(c, x + 5, current_y_above) # Draw from top down
            current_y_above -= (0.05 * inch) # Add line spacing

        # Text to the left of barcode (Series)
        text_left_barcode_lines = []
        if series_name:
            text_left_barcode_lines.append(f"Vol. {series_number}" if series_number else series_name) # Formatted series

        max_text_left_width = barcode_x - (x + 5) - 5 # Space to the left of barcode
        max_text_left_height = barcode_height # Height of barcode area

        optimal_font_size_left, text_block_height_left = _fit_text_to_box(c, text_left_barcode_lines, 'Courier', max_text_left_width, max_text_left_height, initial_font_size=10, alignment=TA_LEFT)

        style_left = styles['Normal']
        style_left.fontName = 'Courier'
        style_left.fontSize = optimal_font_size_left
        style_left.leading = optimal_font_size_left * 1.2 # Line spacing
        style_left.alignment = TA_LEFT

        # Position and rotate text to the left of the barcode
        if text_left_barcode_lines:
            c.saveState()
            # Translate to the bottom-left of the text area, then rotate
            text_origin_x = x + 5 # Start 5 units from left edge
            text_origin_y = y + (LABEL_HEIGHT - text_block_height_left) / 2 + text_block_height_left # Vertically center in left area
            
            c.translate(text_origin_x, text_origin_y)
            c.rotate(90) # Rotate 90 degrees counter-clockwise
            
            # Draw text after rotation and translation
            current_rotated_y = 0 # Relative to new origin
            for line in text_left_barcode_lines:
                p = Paragraph(line, style_left)
                width, height = p.wrapOn(c, max_text_left_height, max_text_left_width) # Swap width/height for rotated text
                current_rotated_y -= height # Move down for current line
                p.drawOn(c, 0, current_rotated_y) # Draw from new origin
                current_rotated_y -= (0.05 * inch) # Add line spacing
            c.restoreState()


def generate_pdf_sheet(book_data_list, output_filename="book_labels.pdf"):
    """Generates a PDF with multiple sheets of Avery 5160 labels."""
    c = canvas.Canvas(output_filename, pagesize=letter)

    label_count = 0
    for book_data in book_data_list:
        for label_type in range(1, 5): # Generate 4 labels for each book
            row = (label_count // LABELS_PER_SHEET_WIDTH) % LABELS_PER_SHEET_HEIGHT
            col = label_count % LABELS_PER_SHEET_WIDTH

            x_pos = LEFT_MARGIN + col * (LABEL_WIDTH + HORIZONTAL_SPACING)
            y_pos = PAGE_HEIGHT - TOP_MARGIN - (row + 1) * (LABEL_HEIGHT + VERTICAL_SPACING)

            # Draw dotted lines for label edges (perimeter of each label cell) with rounded corners
            c.setDash(1, 2) # Dotted line: 1 unit on, 2 units off
            c.setStrokeColorRGB(0, 0, 0) # Black color
            c.setLineWidth(0.5) # Line thickness
            c.roundRect(x_pos, y_pos, LABEL_WIDTH, LABEL_HEIGHT, 5) # 5 units for corner radius

            # Draw solid lines for buffer spaces (between labels, not overlapping dotted lines)
            c.setDash() # Solid line
            c.setStrokeColorRGB(0, 0, 0) # Black color
            c.setLineWidth(0.5) # Line thickness
            
            # Vertical solid lines in the horizontal spacing area
            if col < LABELS_PER_SHEET_WIDTH - 1:
                c.line(x_pos + LABEL_WIDTH, y_pos, x_pos + LABEL_WIDTH + HORIZONTAL_SPACING, y_pos)
                c.line(x_pos + LABEL_WIDTH, y_pos + LABEL_HEIGHT, x_pos + LABEL_WIDTH + HORIZONTAL_SPACING, y_pos + LABEL_HEIGHT)
                # Draw a single solid line in the middle of the horizontal spacing
                c.line(x_pos + LABEL_WIDTH + HORIZONTAL_SPACING / 2, y_pos, x_pos + LABEL_WIDTH + HORIZONTAL_SPACING / 2, y_pos + LABEL_HEIGHT)

            # Horizontal solid lines in the vertical spacing area
            if row < LABELS_PER_SHEET_HEIGHT - 1:
                c.line(x_pos, y_pos - VERTICAL_SPACING, x_pos, y_pos)
                c.line(x_pos + LABEL_WIDTH, y_pos - VERTICAL_SPACING, x_pos + LABEL_WIDTH, y_pos)
                # Draw a single solid line in the middle of the vertical spacing
                c.line(x_pos, y_pos - VERTICAL_SPACING / 2, x_pos + LABEL_WIDTH, y_pos - VERTICAL_SPACING / 2)

            create_label(c, x_pos, y_pos, book_data, label_type)
            label_count += 1

            if label_count % (LABELS_PER_SHEET_WIDTH * LABELS_PER_SHEET_HEIGHT) == 0:
                c.showPage() # Start a new page after a full sheet
                c.setFont('Helvetica', 8) # Reset font for new page

    c.save()
    print(f"Generated {output_filename} with {label_count} labels.")

    # Copy to shared storage
    try:
        shutil.copyfile(output_filename, "/sdcard/Download/" + output_filename)
        print(f"Copied {output_filename} to /sdcard/Download/")
    except Exception as e:
        print(f"Error copying file to shared storage: {e}")

if __name__ == "__main__":
    # Dummy data for testing
    sample_books = [
        {
            'title': "The Hitchhiker's Guide to the Galaxy",
            'authors': 'Douglas Adams',
            'publication_year': 1979,
            'series_name': "Hitchhiker's Guide",
            'series_number': 1,
            'dewey_number': '823.914',
            'inventory_number': 12345,
        },
        {
            'title': 'The Restaurant at the End of the Universe',
            'authors': 'Douglas Adams',
            'publication_year': 1980,
            'series_name': "Hitchhiker's Guide",
            'series_number': 2,
            'dewey_number': '823.914',
            'inventory_number': 12346,
        },
        {
            'title': 'Life, the Universe and Everything',
            'authors': 'Douglas Adams',
            'publication_year': 1982,
            'series_name': "Hitchhiker's Guide",
            'series_number': 3,
            'dewey_number': '823.914',
            'inventory_number': 12347,
        },
        {
            'title': 'So Long, and Thanks for All the Fish',
            'authors': 'Douglas Adams',
            'publication_year': 1984,
            'series_name': "Hitchhiker's Guide",
            'series_number': 4,
            'dewey_number': '823.914',
            'inventory_number': 12348,
        },
        {
            'title': 'Mostly Harmless',
            'authors': 'Douglas Adams',
            'publication_year': 1992,
            'series_name': "Hitchhiker's Guide",
            'series_number': 5,
            'dewey_number': '823.914',
            'inventory_number': 12349,
        },
        {
            'title': 'Pride and Prejudice',
            'authors': 'Jane Austen',
            'publication_year': 1813,
            'series_name': '',
            'series_number': '',
            'dewey_number': '823.7',
            'inventory_number': 54321,
        },
        {
            'title': '1984',
            'authors': 'George Orwell',
            'publication_year': 1949,
            'series_name': '',
            'series_number': '',
            'dewey_number': '823.912',
            'inventory_number': 67890,
        },
        {
            'title': 'To Kill a Mockingbird',
            'authors': 'Harper Lee',
            'publication_year': 1960,
            'series_name': '',
            'series_number': '',
            'dewey_number': '813.54',
            'inventory_number': 11223,
        },
        {
            'title': 'The Great Gatsby',
            'authors': 'F. Scott Fitzgerald',
            'publication_year': 1925,
            'series_name': '',
            'series_number': '',
            'dewey_number': '813.52',
            'inventory_number': 44556,
        },
        {
            'title': 'Moby Dick',
            'authors': 'Herman Melville',
            'publication_year': 1851,
            'series_name': '',
            'series_number': '',
            'dewey_number': '813.3',
            'inventory_number': 77889,
        },
        {
            'title': 'War and Peace',
            'authors': 'Leo Tolstoy',
            'publication_year': 1869,
            'series_name': '',
            'series_number': '',
            'dewey_number': '891.733',
            'inventory_number': 99001,
        },
        {
            'title': 'The Catcher in the Rye',
            'authors': 'J.D. Salinger',
            'publication_year': 1951,
            'series_name': '',
            'series_number': '',
            'dewey_number': '813.54',
            'inventory_number': 22334,
        },
        {
            'title': 'The Hobbit',
            'authors': 'J.R.R. Tolkien',
            'publication_year': 1937,
            'series_name': 'Middle-earth',
            'series_number': 1,
            'dewey_number': '823.912',
            'inventory_number': 55667,
        },
        {
            'title': 'The Lord of the Rings',
            'authors': 'J.R.R. Tolkien',
            'publication_year': 1954,
            'series_name': 'Middle-earth',
            'series_number': 2,
            'dewey_number': '823.912',
            'inventory_number': 88990,
        },
        {
            'title': 'Dune',
            'authors': 'Frank Herbert',
            'publication_year': 1965,
            'series_name': 'Dune Chronicles',
            'series_number': 1,
            'dewey_number': '813.54',
            'inventory_number': 33445,
        },
        {
            'title': 'Foundation',
            'authors': 'Isaac Asimov',
            'publication_year': 1951,
            'series_name': 'Foundation Series',
            'series_number': 1,
            'dewey_number': '813.54',
            'inventory_number': 66778,
        },
        {
            'title': 'Neuromancer',
            'authors': 'William Gibson',
            'publication_year': 1984,
            'series_name': 'Sprawl Trilogy',
            'series_number': 1,
            'dewey_number': '813.54',
            'inventory_number': 99887,
        },
        {
            'title': 'Snow Crash',
            'authors': 'Neal Stephenson',
            'publication_year': 1992,
            'series_name': '',
            'series_number': '',
            'dewey_number': '813.54',
            'inventory_number': 10010,
        },
        {
            'title': 'The Martian',
            'authors': 'Andy Weir',
            'publication_year': 2011,
            'series_name': '',
            'series_number': '',
            'dewey_number': '813.6',
            'inventory_number': 20020,
        },
        {
            'title': 'Project Hail Mary',
            'authors': 'Andy Weir',
            'publication_year': 2021,
            'series_name': '',
            'series_number': '',
            'dewey_number': '813.6',
            'inventory_number': 30030,
        },
        {
            'title': 'Dune Messiah',
            'authors': 'Frank Herbert',
            'publication_year': 1969,
            'series_name': 'Dune Chronicles',
            'series_number': 2,
            'dewey_number': '813.54',
            'inventory_number': 33446,
        },
        {
            'title': 'Children of Dune',
            'authors': 'Frank Herbert',
            'publication_year': 1976,
            'series_name': 'Dune Chronicles',
            'series_number': 3,
            'dewey_number': '813.54',
            'inventory_number': 33447,
        },
        {
            'title': 'God Emperor of Dune',
            'authors': 'Frank Herbert',
            'publication_year': 1981,
            'series_name': 'Dune Chronicles',
            'series_number': 4,
            'dewey_number': '813.54',
            'inventory_number': 33448,
        },
        {
            'title': 'Heretics of Dune',
            'authors': 'Frank Herbert',
            'publication_year': 1984,
            'series_name': 'Dune Chronicles',
            'series_number': 5,
            'dewey_number': '813.54',
            'inventory_number': 33449,
        },
        {
            'title': 'Chapterhouse: Dune',
            'authors': 'Frank Herbert',
            'publication_year': 1985,
            'series_name': 'Dune Chronicles',
            'series_number': 6,
            'dewey_number': '813.54',
            'inventory_number': 33450,
        },
        {
            'title': 'Second Foundation',
            'authors': 'Isaac Asimov',
            'publication_year': 1953,
            'series_name': 'Foundation Series',
            'series_number': 3,
            'dewey_number': '813.54',
            'inventory_number': 66779,
        },
        {
            'title': 'Foundation and Empire',
            'authors': 'Isaac Asimov',
            'publication_year': 1952,
            'series_name': 'Foundation Series',
            'series_number': 2,
            'dewey_number': '813.54',
            'inventory_number': 66780,
        },
        {
            'title': "Foundation's Edge",
            'authors': 'Isaac Asimov',
            'publication_year': 1982,
            'series_name': 'Foundation Series',
            'series_number': 4,
            'dewey_number': '813.54',
            'inventory_number': 66781,
        },
        {
            'title': 'Foundation and Earth',
            'authors': 'Isaac Asimov',
            'publication_year': 1986,
            'series_name': 'Foundation Series',
            'series_number': 5,
            'dewey_number': '813.54',
            'inventory_number': 66782,
        },
        {
            'title': 'Prelude to Foundation',
            'authors': 'Isaac Asimov',
            'publication_year': 1988,
            'series_name': 'Foundation Series',
            'series_number': 6,
            'dewey_number': '813.54',
            'inventory_number': 66783,
        },
        {
            'title': 'Forward the Foundation',
            'authors': 'Isaac Asimov',
            'publication_year': 1993,
            'series_name': 'Foundation Series',
            'series_number': 7,
            'dewey_number': '813.54',
            'inventory_number': 66784,
        },
    ]

    generate_pdf_sheet(sample_books)
