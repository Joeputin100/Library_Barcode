# Barcode and QR Code Label Generator

This project is a Python-based application designed to generate barcode and QR code labels for books. It is currently in a working condition.

**Version:** 1.0